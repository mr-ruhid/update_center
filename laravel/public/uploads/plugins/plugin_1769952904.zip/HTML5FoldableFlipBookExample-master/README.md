# HTML5FoldableFlipBookExample
 HTML5 Flip Book using TurnJS library

An example of using TurnJS library to create a flip book web app.

Book pages are jpg images stored in a folder, then loaded up into this flip book nicely.

Let's say you want to make your own flip book? Convert your book pages into individual jpg images, rename them accordingly from 1 to any number of page, then edit the index.html file, find a JavaScript variable called "maxpage" and set its number.

Get the source code here: https://thirteenov.ciihuy.com/html5-flip-book-using-turnjs-library/

Watch the demo video here: https://youtu.be/GXIeztr6EiY
